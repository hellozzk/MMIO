_base_ = ('/root/autodl-tmp/RTVPNet/mmyolo/configs/yolov8/'
          'yolov8_s_syncbn_fast_8xb16-500e_coco.py')
custom_imports = dict(imports=['RTVPNet'],
                      allow_failed_imports=False)

# hyper-parameters
max_epochs = 200  # Maximum training epochs
close_mosaic_epochs = 2
save_epoch_intervals = 2
text_channels = 512
neck_embed_channels = [128, 256, _base_.last_stage_out_channels // 2]
neck_num_heads = [4, 8, _base_.last_stage_out_channels // 2 // 32]
base_lr = 2e-3
weight_decay = 0.05 / 2
train_batch_size_per_gpu = 8
val_batch_size_per_gpu = 1
# text_model_name = '../pretrained_models/clip-vit-base-patch32-projection'
text_model_name = '/root/autodl-tmp/RTVPNet/openai/clip-vit-base-patch32'
# model settings
classes_train=("Alligator Crack",
    "Bird Drop",
    "Bite Marks",
    "Block crack",
    "Broken",
    "Broken Disc",
    "Cable Break Defect",
    "Cable Thunderbolt Defect",
    "Cable Wear Defect",
    "Clean",
    "Cloth dotted with holes",
    "Cloth riddled with holes",
    "Compression mark",
    "Conner Leaky Bottom",
    "Corrosion",
    "Crack",
    "Crack concrete",
    "Cracks",
    "Craze wind turbine",
    "D0w0",
    "Damage claim",
    "Damaged Or Misaligned",
    "Dirt wind turbine",
    "Dirty Spots",
    "Drippy Bottom",
    "Dusty",
    "Electrical Damage",
    "Erosion",
    "Fabric stain",
    "False Copper",
    "Fine Cracks",
    "Glass Dirty",
    "Glass Loss",
    "Hole",
    "Inclusion",
    "Insulator Glass",
    "Intersection Blur",
    "Iron Oxidation",
    "Leaky Bottom",
    "Length Short",
    "Lignum Blue Stain",
    "Lignum Crack",
    "Lignum Dead Knot",
    "Lignum Knot missing",
    "Lignum Knot with crack",
    "Lignum Live Knot",
    "Lignum Marrow",
    "Lignum Overgrown",
    "Lignum Quartzity",
    "Lignum Resin",
    "Longitudinal Crack",
    "Longitudinal Joint",
    "Manhole",
    "Oil stain",
    "Open Circuit Condition",
    "Orange Peel",
    "Paint Bubble",
    "Paint and peel",
    "Paint peel",
    "Paint peel away",
    "Patch up",
    "Patches",
    "Peel paint and rust",
    "Peel paint issue",
    "Peel paint repair",
    "Peel paint texture",
    "Physical Damage",
    "Pinholes",
    "Pit",
    "Pitted Area",
    "Pitted Shell",
    "Pitted Surface",
    "Pockmarks",
    "Pollution Flashover",
    "Polyme Dirty",
    "Pothole",
    "Repair",
    "Rolled in Scale",
    "Scratch",
    "Scratches",
    "Snow Covered",
    "Spur Defect",
    "Stomata",
    "Topbasi",
    "Transverse Crack",
    "Transverse Joint",
    "Two Hight Glass",
    "Variegated Color",
    "White Line Blur",
    "Wind turbine hole",
    "Yarn break away",
    "Yarn breakage",
    "damged",
    "lack of part",)
classes_val=("Bird Excrement",
    "Black Spot Bubbles",
    "Cable Defect",
    "Cloth with holes",
    "Corrosion turbine",
    "Corrosion win turbine",
    "Crack reinforced concrete",
    "Cracked Damage",
    "Cracks",
    "Craze",
    "Craze turbine",
    "Damaged Disc",
    "Damaged goods",
    "Dirt",
    "Dirt turbine",
    "Dirty",
    "Dirty Flash",
    "Dust",
    "Exposed Bottom",
    "Fringe Scratch",
    "Holey cloth",
    "Insulator",
    "Loss",
    "Missing Hole",
    "Mouse Bite",
    "Open Circuit",
    "Orange Effect",
    "Paint",
    "Paint peeling and chipping",
    "Paint peeling due to moisture",
    "Patch",
    "Peel paint treatment",
    "Pitted",
    "Pockmarks",
    "Polymer Fouling",
    "Rust stain",
    "Scratche Defect",
    "Short",
    "Spur",
    "Spurious Copper",
    "Stomata Pockmarks",
    "Surface crack",
    "Tidy",
    "Tulle",
    "Turbine hole",
    "Two Hight",
    "Way Alligator Crack",
    "Way Intersection Blur",
    "Way Longitudinal Crack",
    "Way Manhole",
    "Way Pothole",
    "Way Repair",
    "Way Transverse Crack",
    "Way White Line Blur",
    "Wood Crack",
    "Wood Dead Knot",
    "Wood Knot Missing",
    "Wood Knot With Crack",
    "Wood Live knot",
    "Wood Marrow",
    "Wood Quartzity",
    "Wood Resin",
    "Yarn break",
    "Yarn break down",)
num_classes =len(classes_val)
num_training_classes =len(classes_train)
model = dict(
    type='RTVPNet_SAM_Detector',
    mm_neck=True,
    num_train_classes=num_training_classes,
    num_test_classes=num_classes,
    data_preprocessor=dict(type='YOLOWDetDataPreprocessor'),
    backbone=dict(
        _delete_=True,
        type='MultiModalYOLOSAMBackbone',
        image_model={{_base_.model.backbone}},
        text_model=dict(
            type='HuggingCLIPLanguageBackbone',
            model_name=text_model_name,
            frozen_modules=['all'])),
    neck=dict(type='Text_Visual_Mut',
              guide_channels=text_channels,
              embed_channels=neck_embed_channels,
              num_heads=neck_num_heads,
              block_cfg=dict(type='MaxSigmoidCSPLayerWithTwoConv')),
    bbox_head=dict(type='RTVPNetHead',
                   head_module=dict(type='RTVPNetHeadModule',
                                    use_bn_head=True,
                                    embed_dims=text_channels,
                                    num_classes=num_training_classes)),
    train_cfg=dict(assigner=dict(num_classes=num_training_classes)))

# dataset settings
text_transform = [
    dict(type='RandomLoadText',
         num_neg_samples=(num_classes, num_classes),
         max_num_samples=num_training_classes,
         padding_to_max=True,
         padding_value=''),
    dict(type='mmdet.PackDetInputs',
         meta_keys=('img_id', 'img_path', 'ori_shape', 'img_shape', 'flip',
                    'flip_direction', 'texts'))
]
train_pipeline = [
    *_base_.pre_transform,
    dict(type='MultiModalMosaic',
         img_scale=_base_.img_scale,
         pad_val=114.0,
         pre_transform=_base_.pre_transform),
    dict(
        type='YOLOv5RandomAffine',
        max_rotate_degree=0.0,
        max_shear_degree=0.0,
        scaling_ratio_range=(1 - _base_.affine_scale, 1 + _base_.affine_scale),
        max_aspect_ratio=_base_.max_aspect_ratio,
        border=(-_base_.img_scale[0] // 2, -_base_.img_scale[1] // 2),
        border_val=(114, 114, 114)),
    *_base_.last_transform[:-1],
    *text_transform,
]
train_pipeline_stage2 = [*_base_.train_pipeline_stage2[:-1], *text_transform]
coco_train_dataset = dict(
    type='MultiModalDataset',
    dataset=dict(
        type='YOLOv5CocoDataset',
        data_root='/root/autodl-tmp/',
        metainfo=dict(classes=classes_train),
        ann_file='Industrial-open/train/annotations/train.json',
        data_prefix=dict(img='/root/autodl-tmp/Industrial-open/train/images/'),
        filter_cfg=dict(filter_empty_gt=False, min_size=32)
        ),
    class_text_path='/root/autodl-tmp/RTVPNet/data/texts/zero_train.json',
    pipeline=train_pipeline)


train_dataloader = dict(batch_size=train_batch_size_per_gpu,
                        collate_fn=dict(type='yolow_collate'),
                        dataset=dict(_delete_=True,
                                     type='ConcatDataset',
                                     datasets=[
                                         coco_train_dataset,
                                     ],
                                     ignore_keys=['classes', 'palette']))

test_pipeline = [
    *_base_.test_pipeline[:-1],
    dict(type='LoadText'),
    dict(type='mmdet.PackDetInputs',
         meta_keys=('img_id', 'img_path', 'ori_shape', 'img_shape',
                    'scale_factor', 'pad_param', 'texts'))
]
coco_val_dataset = dict(
    _delete_=True,
    type='MultiModalDataset',
    dataset=dict(type='YOLOv5CocoDataset',
                 data_root='/root/autodl-tmp/',
                 metainfo=dict(classes=classes_val),
                 test_mode=True,
                 ann_file='/root/autodl-tmp/Industrial-open/val/annotations/val.json',
                 data_prefix=dict(img='/root/autodl-tmp/Industrial-open/val/images/'),
                 batch_shapes_cfg=None),
    class_text_path='/root/autodl-tmp/RTVPNet/data/texts/Open_val.json',
    pipeline=test_pipeline)
val_dataloader = dict(batch_size=val_batch_size_per_gpu,dataset=coco_val_dataset)
test_dataloader = val_dataloader

val_evaluator = dict(type='mmdet.CocoMetric',
                     ann_file='/root/autodl-tmp/Industrial-open/val/annotations/val.json',
                     metric='bbox')
test_evaluator = val_evaluator

# training settings
default_hooks = dict(param_scheduler=dict(max_epochs=max_epochs),
                     checkpoint=dict(interval=save_epoch_intervals,
                                     rule='greater'))
custom_hooks = [
    # dict(type='EMAHook',
    #      ema_type='ExpMomentumEMA',
    #      momentum=0.0001,
    #      update_buffers=True,
    #      strict_load=False,
    #      priority=49),
    dict(type='mmdet.PipelineSwitchHook',
         switch_epoch=max_epochs - close_mosaic_epochs,
         switch_pipeline=train_pipeline_stage2)
]
train_cfg = dict(max_epochs=max_epochs,
                 val_interval=10,
                 dynamic_intervals=[((max_epochs - close_mosaic_epochs),
                                     _base_.val_interval_stage2)])
optim_wrapper = dict(optimizer=dict(
    _delete_=True,
    type='AdamW',
    lr=base_lr,
    weight_decay=weight_decay,
    batch_size_per_gpu=train_batch_size_per_gpu),
                     paramwise_cfg=dict(bias_decay_mult=0.0,
                                        norm_decay_mult=0.0,
                                        custom_keys={
                                            'backbone.text_model':
                                            dict(lr_mult=0.01),
                                            'logit_scale':
                                            dict(weight_decay=0.0)
                                        }),
                     constructor='YOLOWv5OptimizerConstructor')
